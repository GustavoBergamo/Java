package com.gutotech.loteriasapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoteriasApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
