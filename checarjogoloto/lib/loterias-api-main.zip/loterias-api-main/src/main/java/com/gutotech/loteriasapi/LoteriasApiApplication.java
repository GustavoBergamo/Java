package com.gutotech.loteriasapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoteriasApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoteriasApiApplication.class, args);
	}

}
